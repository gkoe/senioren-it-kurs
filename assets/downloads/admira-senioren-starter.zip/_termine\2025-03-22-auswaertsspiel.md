---
layout: termine
title: Auswärtsspiel in Steyr
date: 2025-03-22
time: 14:00
location: Steyr, Sportanlage XYZ
description: Freundschaftsspiel gegen Senioren Steyr, anschließend gemeinsames Essen.
---

Bitte rechtzeitig anreisen. Fahrgemeinschaften über den Stammtisch organisieren.
