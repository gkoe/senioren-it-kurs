---
layout: termine
title: Senioren-Stammtisch
date: 2025-03-05
time: 19:00
location: Vereinslokal Linz
description: Gemütlicher Abend mit Rückblick auf die letzten Spiele.
---

Treffen im Vereinslokal. Neue Gesichter sind herzlich willkommen!
