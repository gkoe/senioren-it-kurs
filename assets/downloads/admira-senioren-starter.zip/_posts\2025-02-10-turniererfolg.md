---
layout: post
title: Turniererfolg gegen ASK Linz
---

Spannendes Spiel und faire Zweikämpfe – am Ende stand ein knapper Sieg gegen den ASK Linz. Danach wurde gemeinsam gefeiert. So macht Fußball Spaß!
