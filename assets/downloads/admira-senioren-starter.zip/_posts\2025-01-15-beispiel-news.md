---
layout: post
title: Erfolgreicher Hallencup der Senioren
---

Unsere Senioren zeigten beim Hallencup vollen Einsatz: starke Paraden, schöne Kombinationen – und vor allem viel Spaß. Danke an alle, die angefeuert haben!
