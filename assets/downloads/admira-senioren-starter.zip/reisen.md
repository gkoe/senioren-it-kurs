---
layout: default
title: Reisen
---

<p class="note">Hier findet ihr Ankündigungen und Informationen zu unseren Ausfahrten und Reisen (Ziele, Termine, Programm, Kosten, Anmeldung). Dieser Bereich ist als einfache Seite angelegt – ideal für Zusammenfassungen und Downloads.</p>

<h2>Nächste Reise</h2>
<ul>
  <li><strong>Ziel:</strong> Wird noch bekannt gegeben</li>
  <li><strong>Datum:</strong> tba</li>
  <li><strong>Programm:</strong> Stadionführung, Freundschaftsspiel, gemeinsames Essen</li>
  <li><strong>Anmeldung:</strong> per E‑Mail an die Vereinsadresse</li>
</ul>
