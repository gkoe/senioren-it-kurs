﻿# Senioren-IT Kurs â€” Jekyll Website

Kurzanleitung:
1. Erstelle ein neues GitHub-Repository namens senioren-it-kurs (oder verwende deinen gewÃ¼nschten Namen).
2. Lege die Dateien (inkl. Ordner ssets/css/ und ssets/downloads/) in das Repo.
3. Lege deine Download-Dateien in ssets/downloads/.
4. Aktiviere GitHub Pages: Repository -> Settings -> Pages -> Source: main branch (Root).
5. Warte kurz, GitHub baut die Seite. Ã–ffne dann die URL https://gkoe.github.io/senioren-it-kurs/ (falls baseurl leer ist, ggf. /repo-name).

Tipps:
- Passe _config.yml url ggf. an.
- Du kannst Termine spÃ¤ter in _data/termine.yml auslagern, falls gewÃ¼nscht.
