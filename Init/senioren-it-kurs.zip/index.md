﻿---
layout: default
title: Start
description: Willkommen beim Senioren-IT Kurs
---

<div class=""wrap"">
  <h2>Willkommen</h2>
  <p>Dies ist die Info-Seite fÃ¼r den Senioren-IT Kurs. Hier findest du die aktuellen Kurstermine und die Materialien zum Download.</p>

  <h3>NÃ¤chste Schritte</h3>
  <ul>
    <li><a href=""{{ '/termine/' | relative_url }}"">Kurstermine ansehen</a></li>
    <li><a href=""{{ '/downloads/' | relative_url }}"">Materialien herunterladen</a></li>
  </ul>

  <section id=""kontakt"">
    <h3>Kontakt</h3>
    <p>FÃ¼r Fragen: <strong>kurs@example.org</strong> (ersetzen durch echte Kontaktadresse)</p>
  </section>
</div>
